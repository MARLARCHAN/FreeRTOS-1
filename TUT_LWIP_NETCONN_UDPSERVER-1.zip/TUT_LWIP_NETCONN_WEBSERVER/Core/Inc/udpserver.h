/*
 * udpserver.h
 *
 *  Created on: Mar 31, 2022
 *      Author: controllerstech
 */

#ifndef INC_UDPSERVER_H_
#define INC_UDPSERVER_H_


void udpserver_init(void);


#endif /* INC_UDPSERVER_H_ */
